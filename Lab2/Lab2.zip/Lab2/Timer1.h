#include <stdint.h>
#include "../inc/tm4c123gh6pm.h"

void Timer1_Init(void);
void Timer1A_Handler(void);
